#!/bin/sh
# Detiene racketclub-gate: bandera de stop + mata procesos e instancias huérfanas.
STOP_FLAG="/apps/.racketclub-gate-stopped"
touch "$STOP_FLAG" 2>/dev/null || true

kill_gate_pids() {
  sig="$1"
  for pid in $(ls /proc 2>/dev/null | grep -E '^[0-9]+$'); do
    f="/proc/$pid/cmdline"
    [ -r "$f" ] || continue
    cmd=$(tr '\0' ' ' < "$f")
    echo "$cmd" | grep -qE 'racketclub_gate\.py|racketclub-gate' || continue
    kill "-$sig" "$pid" 2>/dev/null
  done
}

kill_gate_pids TERM
sleep 2
kill_gate_pids KILL

if command -v fuser >/dev/null 2>&1; then
  fuser -k 8765/tcp 2>/dev/null || true
fi

rm -f /tmp/racketclub-gate.lock
