#!/bin/sh
cd /apps || exit 1
export PYTHONPATH=/apps
export VERSION=1.0.14-fase2
exec -a racketclub-gate python3 /apps/racketclub_gate.py
