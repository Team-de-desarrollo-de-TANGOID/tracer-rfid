#!/bin/sh
for pid in $(ls /proc 2>/dev/null | grep -E '^[0-9]+$'); do
  f="/proc/$pid/cmdline"
  [ -r "$f" ] || continue
  if tr '\0' ' ' < "$f" | grep -q racketclub_gate.py; then
    kill -TERM "$pid" 2>/dev/null
  fi
done
