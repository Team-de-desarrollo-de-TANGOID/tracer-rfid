#!/bin/sh
cd /apps || exit 1
export VERSION=1.0.2-fase1
exec python3 /apps/racketclub_gate.py
