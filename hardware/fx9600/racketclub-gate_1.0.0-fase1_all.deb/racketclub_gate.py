#!/usr/bin/env python3
"""
Racket Club Fase 1 — copia fiel de Tag-Detection (GEC/Zebra).
Sin configurar IoT Connector ni cloud endpoints en la consola web.
Solo: pyziotc + REST local 127.0.0.1:80 (/cloud/start, /cloud/mode, ...).
"""
import json
import os
import signal
import time

import pyziotc

from Logger import Logger
from RestAPI import RestAPI
from INIFile import INIFile

if os.environ.get("INI_LOCATION") is not None:
    Ini = INIFile(os.getenv("INI_LOCATION"))
else:
    Ini = INIFile(os.path.join(os.path.dirname(os.path.abspath(__file__)), "config.ini"))

DEBUG_SERVER = Ini.getStr("General", "DebugServer", "")
DEBUG_PORT = Ini.getInt("General", "DebugPort", 40514)
LOG_ONLY_TO_CONSOLE = Ini.getBool("General", "Log_Only_To_Console", False)
REST_API_RETRY_COUNT = Ini.getInt("General", "Retry", 3)
SEEN_TIMEOUT = Ini.getInt("General", "Seen_Timeout_in_ms", 5000)
SCAN_TIMEOUT = Ini.getInt("General", "Scan_Timeout_in_ms", 3000)
GPO_GREEN = Ini.getInt("GPO", "GPO_Green", 0)
GPI_TRIGGER = Ini.getInt("GPI", "GPI_Trigger", 0)
GPI_TRIGGER_LEVEL = Ini.getStr("GPI", "GPI_Trigger_Lvl", "LOW")
GPI_DEBOUNCE = Ini.getInt("General", "GPI_Debounce_in_ms", 0)

Stop = False
GPI = ["NA", "Unknown", "Unknown", "Unknown", "Unknown"]
ScanTime = 0
TagTimeout = 0
SeenTags = set()

ziotcObject = pyziotc.Ziotc()
logger = Logger(DEBUG_SERVER, DEBUG_PORT, LOG_ONLY_TO_CONSOLE)
restAPI = RestAPI(logger, REST_API_RETRY_COUNT, ziotcObject)


def sigHandler(signum, frame):
    global Stop
    Stop = True


def passthru_callback(msg_in):
    return b"unrecognized command"


def new_msg_callback(msg_type, msg_in):
    if msg_type == pyziotc.MSG_IN_GPI:
        process_gpi(msg_in)
    if msg_type == pyziotc.MSG_IN_JSON:
        process_tag(msg_in)


def process_gpi(msg_in):
    global ScanTime, GPI
    msg = json.loads(msg_in)
    if msg["type"] != "GPI":
        return
    pin = msg["pin"]
    logger.info(f"GPI State :{pin} -> {msg['state']}")
    GPI[int(pin)] = msg["state"]
    if pin == GPI_TRIGGER and msg["state"] == GPI_TRIGGER_LEVEL:
        logger.info("Triggered !!!")
        ScanTime = time.time() + (SCAN_TIMEOUT / 1000)


def _extract_tid(data):
    for key in ("TID", "tid", "tidHex"):
        val = data.get(key)
        if val and str(val).strip():
            return str(val).upper().strip()
    return None


def process_tag(msg_in):
    global TagTimeout, SeenTags

    if TagTimeout < time.time():
        SeenTags.clear()

    tag = json.loads(msg_in)
    data = tag.get("data") or {}
    tid = _extract_tid(data)
    epc = str(data.get("idHex", "") or "")
    key = tid or epc.upper()
    if not key:
        return

    if key in SeenTags:
        return

    SeenTags.add(key)
    ant = data.get("antenna", data.get("antennaId", ""))
    rssi = data.get("peakRssi", data.get("rssi", ""))

    if tid:
        logger.info(f"LECTURA TID={tid} epc={epc} ant={ant} rssi={rssi}")
    else:
        logger.info(f"LECTURA epc={epc} ant={ant} rssi={rssi} (sin TID)")

    TagTimeout = time.time() + (SEEN_TIMEOUT / 1000)


def configureReader():
    config = {"GPIO-LED": {"GPODefaults": {"1": "LOW", "2": "LOW", "3": "LOW"}}}
    logger.debug("LED Config -> " + json.dumps(config))
    restAPI.setConfig(json.dumps(config))

    mode = {
        "type": "CUSTOM",
        "tagMetaData": ["ANTENNA", "RSSI", "SEEN_COUNT", "TID", "EPC"],
        "environment": "AUTO_DETECT",
        "antennas": [],
        "transmitPower": [],
        "reportFilter": {"duration": 0, "type": "RADIO_WIDE"},
    }
    if GPI_TRIGGER != 0:
        mode["radioStartConditions"] = {
            "type": "GPI",
            "gpis": [
                {
                    "port": GPI_TRIGGER,
                    "signal": GPI_TRIGGER_LEVEL,
                    "debounceTime": GPI_DEBOUNCE,
                }
            ],
        }
    for i in range(1, 3):
        if Ini.getBool("Antenna_" + str(i), "Enabled", False):
            mode["antennas"].append(i)
            mode["transmitPower"].append(Ini.getFloat("Antenna_" + str(i), "Power", 19.2))
    logger.debug("Operation Mode -> " + json.dumps(mode))
    restAPI.setMode(json.dumps(mode))


signal.signal(signal.SIGINT, sigHandler)
signal.signal(signal.SIGTERM, sigHandler)

logger.info("racketclub-gate fase1 pid=" + str(os.getpid()))
logger.debug("Reader Version: " + str(restAPI.getReaderVersion()))
logger.debug("Reader Serial Number: " + str(restAPI.getReaderSerial()))
Ini.dumpConfig(logger)

restAPI.setFastGPO(1, False)
restAPI.setFastGPO(2, False)
restAPI.setFastGPO(3, False)
restAPI.stopInventory()
configureReader()

ziotcObject.reg_new_msg_callback(new_msg_callback)
ziotcObject.reg_pass_through_callback(passthru_callback)
ziotcObject.enableGPIEvents()
restAPI.startInventory()

while not Stop:
    time.sleep(0.2)
    if GPO_GREEN:
        restAPI.setFastGPO(GPO_GREEN, TagTimeout > time.time())

restAPI.stopInventory()
restAPI.setFastGPO(1, False)
restAPI.setFastGPO(2, False)
restAPI.setFastGPO(3, False)
logger.info("Stopped")
